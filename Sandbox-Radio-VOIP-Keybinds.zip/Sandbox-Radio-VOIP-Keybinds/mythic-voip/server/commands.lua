function RegisterChatCommands()
	-- Chat:RegisterCommand('vsync', function(source, args, rawCommand)
	--     TriggerClientEvent('VOIP:Client:Sync', source)
	-- end, {
	--     help = 'Resync VOIP',
	-- }, 0)

	-- Chat:RegisterCommand("gag", function(source, args, rawCommand)
	-- 	TriggerClientEvent("VOIP:Client:Gag:Use", source)
	-- end, {
	-- 	help = "Gag Self",
	-- }, 0)
end
