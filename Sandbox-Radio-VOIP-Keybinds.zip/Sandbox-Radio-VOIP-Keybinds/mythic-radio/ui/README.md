# fivem-react-boilerplate

# Quick start
### 1. Clone repo
```
git clone https://github.com/2277/fivem-react-boilerplate.git html
```

### 2. Install dependencies
```
cd html
npm install
```

### 3. Build
```
npm run build
```

### 4. Copy the contents of the generated manifest to your resource manifest!

# Commands
### Run locally for development
```
npm run start
```
